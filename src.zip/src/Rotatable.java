public interface Rotatable {
    void rotateRight();
    void rotateLeft();
}

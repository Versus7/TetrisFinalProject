public enum shapeType {
    LINE,
    SQUARE,
    PYRAMID,
    RSNAKE,
    LSNAKE,
    LEFTL,
    RIGHTL
}

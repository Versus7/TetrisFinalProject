public enum RotationState {
    TOP,
    RIGHT,
    BOTTOM,
    LEFT
}

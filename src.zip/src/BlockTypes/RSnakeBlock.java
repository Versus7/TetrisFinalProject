package BlockTypes;
import Models.Piece;
import Models.shapeType;

public class RSnakeBlock extends Piece {
    public RSnakeBlock(int x) {
        super(shapeType.RSNAKE, x, -2);
    }
}
package BlockTypes;
import Models.Piece;
import Models.shapeType;

public class LeftL extends Piece {
    public LeftL(int x) {
        super(shapeType.LEFTL, x, -2);
    }
}
package BlockTypes;
import Models.Piece;
import Models.shapeType;

public class LSnakeBlock extends Piece {
    public LSnakeBlock(int x) {
        super(shapeType.LSNAKE, x, -2);
    }
}
package BlockTypes;
import Models.Piece;
import Models.shapeType;

public class RightL extends Piece {
    public RightL(int x) {
        super(shapeType.RIGHTL, x, -2);
    }
}
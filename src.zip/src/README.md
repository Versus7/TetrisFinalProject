# TODO
* Create a grid class to house all final values of blocks
* Switch focus from blocks in the Listener class (also generate new blocks in the Listener class)
    * Generation should include new colors, and different shape types
* Using new grid class, write better collision detection system in Piece class
* Begin adding visual indicators of score, etc
* Continue adding different shape types to Piece class, consider extracting out enums to another class

***

Final step: Fix abstraction, encapsulation, polymorphism, refactor design of most code